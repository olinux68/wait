const mongoose = require('mongoose');
const QueueSchema = new mongoose.Schema({
  name: { type: String, required: true },
  ownerId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  participants: [{ userId: mongoose.Schema.Types.ObjectId, position: Number }]
});
module.exports = mongoose.model('Queue', QueueSchema);
