
const express = require('express');
const jwt = require('jsonwebtoken');
const Queue = require('../models/Queue');
const router = express.Router();

/**
 * @swagger
 * tags:
 *   name: Queue
 *   description: Queue management related routes
 */

/**
 * @swagger
 * securitySchemes:
 *   BearerAuth:
 *     type: http
 *     scheme: bearer
 *     bearerFormat: JWT
 */

const auth = (req, res, next) => {
  const token = req.header('Authorization').replace('Bearer ', '');
  try {
    const decoded = jwt.verify(token, 'votreSecretJWT');
    req.userId = decoded.userId;
    next();
  } catch (err) {
    res.status(401).send('Please authenticate');
  }
};

/**
 * @swagger
 * components:
 *   schemas:
 *     Participant:
 *       type: object
 *       properties:
 *         userId:
 *           type: string
 *         name:
 *           type: string
 *         position:
 *           type: integer
 *     Queue:
 *       type: object
 *       properties:
 *         _id:
 *           type: string
 *         name:
 *           type: string
 *         ownerId:
 *           type: string
 *         participants:
 *           type: array
 *           items:
 *             $ref: '#/components/schemas/Participant'
 */

/**
 * @swagger
 * /api/create:
 *   post:
 *     summary: Create a new queue
 *     tags: [Queue]
 *     security:
 *       - BearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - name
 *             properties:
 *               name:
 *                 type: string
 *     responses:
 *       201:
 *         description: Queue created successfully
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Queue'
 *       500:
 *         description: Internal server error
 */
router.post('/create', auth, async (req, res) => {
  try {
    const { name } = req.body;
    const queue = new Queue({ name, ownerId: req.userId, participants: [] });
    await queue.save();
    res.status(201).send(queue);
  } catch (error) {
    res.status(500).send('Internal server error');
  }
});

/**
 * @swagger
 * /api/{queueId}/join:
 *   post:
 *     summary: Join a queue
 *     tags: [Queue]
 *     parameters:
 *       - in: path
 *         name: queueId
 *         required: true
 *         schema:
 *           type: string
 *         description: The ID of the queue to join
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - userId
 *               - name
 *             properties:
 *               userId:
 *                 type: string
 *               name:
 *                 type: string
 *     responses:
 *       201:
 *         description: Joined the queue successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 position:
 *                   type: integer
 *       400:
 *         description: Name is required
 *       404:
 *         description: Queue not found
 *       500:
 *         description: Internal server error
 */
router.post('/:queueId/join', async (req, res) => {
  try {
    const { queueId } = req.params;
    const { userId, name } = req.body;

    if (!name) {
      return res.status(400).send('Name is required');
    }

    const queue = await Queue.findById(queueId);
    if (!queue) {
      return res.status(404).send('Queue not found');
    }

    const position = queue.participants.length + 1;
    queue.participants.push({ userId, name, position });
    await queue.save();

    const io = req.app.get('io');
    io.emit('update', { queueId, userId, name, position });

    res.status(201).send({ position });
  } catch (error) {
    res.status(500).send('Internal server error');
  }
});

/**
 * @swagger
 * /api/{queueId}/position/{userId}:
 *   get:
 *     summary: Get user's position in the queue
 *     tags: [Queue]
 *     parameters:
 *       - in: path
 *         name: queueId
 *         required: true
 *         schema:
 *           type: string
 *         description: The ID of the queue
 *       - in: path
 *         name: userId
 *         required: true
 *         schema:
 *           type: string
 *         description: The ID of the user
 *     responses:
 *       200:
 *         description: User's position in the queue
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 position:
 *                   type: integer
 *       404:
 *         description: Queue or user not found
 *       500:
 *         description: Internal server error
 */
router.get('/:queueId/position/:userId', async (req, res) => {
  try {
    const { queueId, userId } = req.params;

    const queue = await Queue.findById(queueId);
    if (!queue) {
      return res.status(404).send('Queue not found');
    }

    const participant = queue.participants.find(p => p.userId.toString() === userId);
    if (!participant) {
      return res.status(404).send('User not in queue');
    }

    res.send({ position: participant.position });
  } catch (error) {
    res.status(500).send('Internal server error');
  }
});

/**
 * @swagger
 * /api/{queueId}:
 *   delete:
 *     summary: Delete a queue
 *     tags: [Queue]
 *     security:
 *       - BearerAuth: []
 *     parameters:
 *       - in: path
 *         name: queueId
 *         required: true
 *         schema:
 *           type: string
 *         description: The ID of the queue to delete
 *     responses:
 *       200:
 *         description: Queue deleted successfully
 *       403:
 *         description: Unauthorized
 *       404:
 *         description: Queue not found
 *       500:
 *         description: Internal server error
 */
router.delete('/:queueId', auth, async (req, res) => {
  try {
    const { queueId } = req.params;
    const queue = await Queue.findById(queueId);

    if (!queue) {
      return res.status(404).send('Queue not found');
    }

    if (queue.ownerId.toString() !== req.userId) {
      return res.status(403).send('Unauthorized');
    }

    await queue.deleteOne();
    res.status(200).send('Queue deleted successfully');
  } catch (error) {
    res.status(500).send('Internal server error');
  }
});

module.exports = router;
