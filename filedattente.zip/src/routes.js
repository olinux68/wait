import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Login from './components/Auth/Login';
import Register from './components/Auth/Register';
import CreateQueue from './components/Queue/CreateQueue';
import JoinQueue from './components/Queue/JoinQueue';
import Position from './components/Position';
import Home from './components/Home'; // Assurez-vous que ce composant existe
import Dashboard from './components/Dashboard'; // Importez le nouveau composant

const AppRoutes = () => (
  <Router>
    <Routes>
      <Route path="/" element={<Home />} /> {/* Route pour la racine */}
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />
      <Route path="/create-queue" element={<CreateQueue />} />
      <Route path="/join-queue" element={<JoinQueue />} />
      <Route path="/position" element={<Position />} />
      <Route path="/dashboard" element={<Dashboard />} /> {/* Nouvelle route pour le Dashboard */}
      {/* Ajoutez d’autres routes ici si nécessaire */}
    </Routes>
  </Router>
);

export default AppRoutes;
